<hr/>
<div id="footerContainer">
    <nav>
        <ul class="nav flex-column flex-sm-row justify-content-center">
            <li class="nav-item">
                <a class="nav-link" href="./terms-and-conditions.php">Terms and Conditions</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="./contact-us.php">Contact Us</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="./FAQs.php">FAQs</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="./cookies.php">Cookies</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="./privacy.php">Privacy</a>
            </li>
        </ul>
    </nav>

    <small>Copyright &copy; 2022 Cool CardZ Group PLC</small>
</div>